[![ChromatoPy Logo](misc/chromatoPy.png)](https://github.com/GerardOtiniano/chromatoPy/blob/2b36a74ed639d5c30ae1e143843c1532b0a84237/misc/chromatoPy.png)

# chromatoPy (1.0.0) - standalone application

## Installation

Please contact Gerard Otiniano for an installable version of the app for macOS (.dmg is too large for GitHub). Alternatively, feel free clone the repository and build a working version of the app for any OS using briefcase.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Contact

For questions or inquiries, please contact:

- Author: Dr. Gerard Otiniano & Dr. Elizabeth Thomas
- Email: gerardot@buffalo.edu
