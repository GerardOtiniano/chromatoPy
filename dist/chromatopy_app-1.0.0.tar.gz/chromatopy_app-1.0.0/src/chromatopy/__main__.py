from chromatopy.config.chromatoPy_front_ui import ChromatoPyApp

def main() -> None:
    app = ChromatoPyApp("ChromatoPy", "com.GerardOtiniano.chromatopy")
    app.main_loop()

if __name__ == "__main__":
    main()